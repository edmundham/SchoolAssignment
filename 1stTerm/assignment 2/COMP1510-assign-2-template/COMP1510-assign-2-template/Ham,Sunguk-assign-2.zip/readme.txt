[Sunguk (Edmund) Ham], [A00979841], [E], [Mar 5th, 2017]

This assignment is [100]% complete.


------------------------
Question one (TriangleArea) status:

[complete]

------------------------
Question two (CylinderStats) status:

[complete]

------------------------
Question three (Bookshelf) status:

[complete]

------------------------
Question four (TrafficLight) status:

[complete]
