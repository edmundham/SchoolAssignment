[Sunguk (Edmund) Ham], [A00979841], [E], [April 12th]

This assignment is [100]% complete.


------------------------
Question one (Statistics) status:

[complete]

------------------------
Question two (DrawRectangle) status:

[complete]

------------------------
Question three (StopWatch) status:

[complete]